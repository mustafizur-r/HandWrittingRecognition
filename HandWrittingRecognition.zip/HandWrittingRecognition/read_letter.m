
function letter=read_letter(imagn,num_letras)

global templates
comp=[ ];


 for n=1:num_letras
    
    sem=corr2(templates{1,n},imagn);
    comp=[comp sem];
    
    %pause(1)
end

vd=find(comp==max(comp));
%*-*-*-*-*-*-*-*-*-*-*-*-*-
if vd==1
    letter='A';
elseif vd==2
    letter='A';
elseif vd==3
    letter='A';
elseif vd==4
    letter='A';
elseif vd==5
    letter='A';
elseif vd==6
    letter='A';
elseif vd==7
    letter='A';
elseif vd==8
    letter='A';
elseif vd==9
    letter='A';
elseif vd==10
    letter='A';
elseif vd==11
    letter='A';
elseif vd==12
    letter='A';
elseif vd==13
    letter='A';
elseif vd==14
    letter='A';
elseif vd==15
    letter='A';

    %*-*-*-*-*

elseif vd==15+1
    letter='B';
elseif vd==15+2
    letter='B';
elseif vd==15+3
    letter='B';
elseif vd==15+4
    letter='B';
elseif vd==15+5
    letter='B';
elseif vd==15+6
    letter='B';
elseif vd==15+7
    letter='B';
elseif vd==15+8
    letter='B';
elseif vd==15+9
    letter='B';
elseif vd==15+10
    letter='B';
elseif vd==15+11
    letter='B';
elseif vd==15+12
    letter='B';
elseif vd==15+13
    letter='B';
elseif vd==15+14
    letter='B';
elseif vd==15+15
    letter='B';

%*-*-*-*-*

elseif vd==2*15+1
    letter='C';
elseif vd==2*15+2
    letter='C';
elseif vd==2*15+3
    letter='C';
elseif vd==2*15+4
    letter='C';
elseif vd==2*15+5
    letter='C';
elseif vd==2*15+6
    letter='C';
elseif vd==2*15+7
    letter='C';
elseif vd==2*15+8
    letter='C';
elseif vd==2*15+9
    letter='C';
elseif vd==2*15+10
    letter='C';
elseif vd==2*15+11
    letter='C';
elseif vd==2*15+12
    letter='C';
elseif vd==2*15+13
    letter='C';
elseif vd==2*15+14
    letter='C';
elseif vd==2*15+15
    letter='C';

    %*-*-*-*-*

elseif vd==3*15+1
    letter='D';
elseif vd==3*15+2
    letter='D';
elseif vd==3*15+3
    letter='D';
elseif vd==3*15+4
    letter='D';
elseif vd==3*15+5
    letter='D';
elseif vd==3*15+6
    letter='D';
elseif vd==3*15+7
    letter='D';
elseif vd==3*15+8
    letter='D';
elseif vd==3*15+9
    letter='D';
elseif vd==3*15+10
    letter='D';
elseif vd==3*15+11
    letter='D';
elseif vd==3*15+12
    letter='D';
elseif vd==3*15+13
    letter='D';
elseif vd==3*15+14
    letter='D';
elseif vd==3*15+15
    letter='D';

    %*-*-*-*-*
elseif vd==4*15+1
    letter='E';
elseif vd==4*15+2
    letter='E';
elseif vd==4*15+3
    letter='E';
elseif vd==4*15+4
    letter='E';
elseif vd==4*15+5
    letter='E';
elseif vd==4*15+6
    letter='E';
elseif vd==4*15+7
    letter='E';
elseif vd==4*15+8
    letter='E';
elseif vd==4*15+9
    letter='E';
elseif vd==4*15+10
    letter='E';
elseif vd==4*15+11
    letter='E';
elseif vd==4*15+12
    letter='E';
elseif vd==4*15+13
    letter='E';
elseif vd==4*15+14
    letter='E';
elseif vd==4*15+15
    letter='E';

    %*-*-*-*-*

elseif vd==5*15+1
    letter='F';
elseif vd==5*15+2
    letter='F';
elseif vd==5*15+3
    letter='F';
elseif vd==5*15+4
    letter='F';
elseif vd==5*15+5
    letter='F';
elseif vd==5*15+6
    letter='F';
elseif vd==5*15+7
    letter='F';
elseif vd==5*15+8
    letter='F';
elseif vd==5*15+9
    letter='F';
elseif vd==5*15+10
    letter='F';
elseif vd==5*15+11
    letter='F';
elseif vd==5*15+12
    letter='F';
elseif vd==5*15+13
    letter='F';
elseif vd==5*15+14
    letter='F';
elseif vd==5*15+15
    letter='F';

%*-*-*-*-*

elseif vd==6*15+1
    letter='G';
elseif vd==6*15+2
    letter='G';
elseif vd==6*15+3
    letter='G';
elseif vd==6*15+4
    letter='G';
elseif vd==6*15+5
    letter='G';
elseif vd==6*15+6
    letter='G';
elseif vd==6*15+7
    letter='G';
elseif vd==6*15+8
    letter='G';
elseif vd==6*15+9
    letter='G';
elseif vd==6*15+10
    letter='G';
elseif vd==6*15+11
    letter='G';
elseif vd==6*15+12
    letter='G';
elseif vd==6*15+13
    letter='G';
elseif vd==6*15+14
    letter='G';
elseif vd==6*15+15
    letter='G';

    %*-*-*-*-*

elseif vd==7*15+1
    letter='H';
elseif vd==7*15+2
    letter='H';
elseif vd==7*15+3
    letter='H';
elseif vd==7*15+4
    letter='H';
elseif vd==7*15+5
    letter='H';
elseif vd==7*15+6
    letter='H';
elseif vd==7*15+7
    letter='H';
elseif vd==7*15+8
    letter='H';
elseif vd==7*15+9
    letter='H';
elseif vd==7*15+10
    letter='H';
elseif vd==7*15+11
    letter='H';
elseif vd==7*15+12
    letter='H';
elseif vd==7*15+13
    letter='H';
elseif vd==7*15+14
    letter='H';
elseif vd==7*15+15
    letter='H';

    %*-*-*-*-*
elseif vd==8*15+1
    letter='I';
elseif vd==8*15+2
    letter='I';
elseif vd==8*15+3
    letter='I';
elseif vd==8*15+4
    letter='I';
elseif vd==8*15+5
    letter='I';
elseif vd==8*15+6
    letter='I';
elseif vd==8*15+7
    letter='I';
elseif vd==8*15+8
    letter='I';
elseif vd==8*15+9
    letter='I';
elseif vd==8*15+10
    letter='I';
elseif vd==8*15+11
    letter='I';
elseif vd==8*15+12
    letter='I';
elseif vd==8*15+13
    letter='I';
elseif vd==8*15+14
    letter='I';
elseif vd==8*15+15
    letter='I';

    %*-*-*-*-*

elseif vd==9*15+1
    letter='J';
elseif vd==9*15+2
    letter='J';
elseif vd==9*15+3
    letter='J';
elseif vd==9*15+4
    letter='J';
elseif vd==9*15+5
    letter='J';
elseif vd==9*15+6
    letter='J';
elseif vd==9*15+7
    letter='J';
elseif vd==9*15+8
    letter='J';
elseif vd==9*15+9
    letter='J';
elseif vd==9*15+10
    letter='J';
elseif vd==9*15+11
    letter='J';
elseif vd==9*15+12
    letter='J';
elseif vd==9*15+13
    letter='J';
elseif vd==9*15+14
    letter='J';
elseif vd==9*15+15
    letter='J';

%*-*-*-*-*

elseif vd==10*15+1
    letter='K';
elseif vd==10*15+2
    letter='K';
elseif vd==10*15+3
    letter='K';
elseif vd==10*15+4
    letter='K';
elseif vd==10*15+5
    letter='K';
elseif vd==10*15+6
    letter='K';
elseif vd==10*15+7
    letter='K';
elseif vd==10*15+8
    letter='K';
elseif vd==10*15+9
    letter='K';
elseif vd==10*15+10
    letter='K';
elseif vd==10*15+11
    letter='K';
elseif vd==10*15+12
    letter='K';
elseif vd==10*15+13
    letter='K';
elseif vd==10*15+14
    letter='K';
elseif vd==10*15+15
    letter='K';

    %*-*-*-*-*

elseif vd==11*15+1
    letter='L';
elseif vd==11*15+2
    letter='L';
elseif vd==11*15+3
    letter='L';
elseif vd==11*15+4
    letter='L';
elseif vd==11*15+5
    letter='L';
elseif vd==11*15+6
    letter='L';
elseif vd==11*15+7
    letter='L';
elseif vd==11*15+8
    letter='L';
elseif vd==11*15+9
    letter='L';
elseif vd==11*15+10
    letter='L';
elseif vd==11*15+11
    letter='L';
elseif vd==11*15+12
    letter='L';
elseif vd==11*15+13
    letter='L';
elseif vd==11*15+14
    letter='L';
elseif vd==11*15+15
    letter='L';

    %*-*-*-*-*
elseif vd==12*15+1
    letter='M';
elseif vd==12*15+2
    letter='M';
elseif vd==12*15+3
    letter='M';
elseif vd==12*15+4
    letter='M';
elseif vd==12*15+5
    letter='M';
elseif vd==12*15+6
    letter='M';
elseif vd==12*15+7
    letter='M';
elseif vd==12*15+8
    letter='M';
elseif vd==12*15+9
    letter='M';
elseif vd==12*15+10
    letter='M';
elseif vd==12*15+11
    letter='M';
elseif vd==12*15+12
    letter='M';
elseif vd==12*15+13
    letter='M';
elseif vd==12*15+14
    letter='M';
elseif vd==12*15+15
    letter='M';

    %*-*-*-*-*

elseif vd==13*15+1
    letter='N';
elseif vd==13*15+2
    letter='N';
elseif vd==13*15+3
    letter='N';
elseif vd==13*15+4
    letter='N';
elseif vd==13*15+5
    letter='N';
elseif vd==13*15+6
    letter='N';
elseif vd==13*15+7
    letter='N';
elseif vd==13*15+8
    letter='N';
elseif vd==13*15+9
    letter='N';
elseif vd==13*15+10
    letter='N';
elseif vd==13*15+11
    letter='N';
elseif vd==13*15+12
    letter='N';
elseif vd==13*15+13
    letter='N';
elseif vd==13*15+14
    letter='N';
elseif vd==13*15+15
    letter='N';

%*-*-*-*-*

elseif vd==14*15+1
    letter='O';
elseif vd==14*15+2
    letter='O';
elseif vd==14*15+3
    letter='O';
elseif vd==14*15+4
    letter='O';
elseif vd==14*15+5
    letter='O';
elseif vd==14*15+6
    letter='O';
elseif vd==14*15+7
    letter='O';
elseif vd==14*15+8
    letter='O';
elseif vd==14*15+9
    letter='O';
elseif vd==14*15+10
    letter='O';
elseif vd==14*15+11
    letter='O';
elseif vd==14*15+12
    letter='O';
elseif vd==14*15+13
    letter='O';
elseif vd==14*15+14
    letter='O';
elseif vd==14*15+15
    letter='O';

    %*-*-*-*-*

elseif vd==15*15+1
    letter='P';
elseif vd==15*15+2
    letter='P';
elseif vd==15*15+3
    letter='P';
elseif vd==15*15+4
    letter='P';
elseif vd==15*15+5
    letter='P';
elseif vd==15*15+6
    letter='P';
elseif vd==15*15+7
    letter='P';
elseif vd==15*15+8
    letter='P';
elseif vd==15*15+9
    letter='P';
elseif vd==15*15+10
    letter='P';
elseif vd==15*15+11
    letter='P';
elseif vd==15*15+12
    letter='P';
elseif vd==15*15+13
    letter='P';
elseif vd==15*15+14
    letter='P';
elseif vd==15*15+15
    letter='P';

    %*-*-*-*-*
    

elseif vd==16*15+1
    letter='Q';
elseif vd==16*15+2
    letter='Q';
elseif vd==16*15+3
    letter='Q';
elseif vd==16*15+4
    letter='Q';
elseif vd==16*15+5
    letter='Q';
elseif vd==5*15+6
    letter='Q';
elseif vd==16*15+7
    letter='Q';
elseif vd==16*15+8
    letter='Q';
elseif vd==16*15+9
    letter='Q';
elseif vd==16*15+10
    letter='Q';
elseif vd==16*15+11
    letter='Q';
elseif vd==16*15+12
    letter='Q';
elseif vd==16*15+13
    letter='Q';
elseif vd==16*15+14
    letter='Q';
elseif vd==16*15+15
    letter='Q';

%*-*-*-*-*

elseif vd==17*15+1
    letter='R';
elseif vd==17*15+2
    letter='';
elseif vd==17*15+3
    letter='R';
elseif vd==17*15+4
    letter='R';
elseif vd==6*15+5
    letter='R';
elseif vd==17*15+6
    letter='R';
elseif vd==17*15+7
    letter='R';
elseif vd==17*15+8
    letter='R';
elseif vd==17*15+9
    letter='R';
elseif vd==17*15+10
    letter='R';
elseif vd==17*15+11
    letter='R';
elseif vd==17*15+12
    letter='R';
elseif vd==17*15+13
    letter='R';
elseif vd==17*15+14
    letter='R';
elseif vd==17*15+15
    letter='R';

    %*-*-*-*-*

elseif vd==18*15+1
    letter='S';
elseif vd==18*15+2
    letter='S';
elseif vd==7*15+3
    letter='S';
elseif vd==18*15+4
    letter='S';
elseif vd==18*15+5
    letter='S';
elseif vd==18*15+6
    letter='S';
elseif vd==18*15+7
    letter='S';
elseif vd==18*15+8
    letter='S';
elseif vd==18*15+9
    letter='S';
elseif vd==18*15+10
    letter='S';
elseif vd==18*15+11
    letter='S';
elseif vd==18*15+12
    letter='S';
elseif vd==18*15+13
    letter='S';
elseif vd==18*15+14
    letter='S';
elseif vd==18*15+15
    letter='S';

    %*-*-*-*-*
elseif vd==19*15+1
    letter='T';
elseif vd==19*15+2
    letter='T';
elseif vd==19*15+3
    letter='T';
elseif vd==19*15+4
    letter='T';
elseif vd==19*15+5
    letter='T';
elseif vd==19*15+6
    letter='T';
elseif vd==19*15+7
    letter='T';
elseif vd==19*15+8
    letter='T';
elseif vd==19*15+9
    letter='T';
elseif vd==19*15+10
    letter='T';
elseif vd==19*15+11
    letter='T';
elseif vd==19*15+12
    letter='T';
elseif vd==19*15+13
    letter='T';
elseif vd==19*15+14
    letter='T';
elseif vd==19*15+15
    letter='T';

    %*-*-*-*-*

elseif vd==20*15+1
    letter='U';
elseif vd==20*15+2
    letter='U';
elseif vd==20*15+3
    letter='U';
elseif vd==20*15+4
    letter='U';
elseif vd==20*15+5
    letter='U';
elseif vd==20*15+6
    letter='U';
elseif vd==20*15+7
    letter='U';
elseif vd==20*15+8
    letter='U';
elseif vd==20*15+9
    letter='U';
elseif vd==20*15+10
    letter='U';
elseif vd==20*15+11
    letter='U';
elseif vd==20*15+12
    letter='U';
elseif vd==20*15+13
    letter='U';
elseif vd==20*15+14
    letter='U';
elseif vd==20*15+15
    letter='U';

%*-*-*-*-*

elseif vd==21*15+1
    letter='V';
elseif vd==21*15+2
    letter='V';
elseif vd==21*15+3
    letter='V';
elseif vd==21*15+4
    letter='V';
elseif vd==21*15+5
    letter='V';
elseif vd==21*15+6
    letter='V';
elseif vd==21*15+7
    letter='V';
elseif vd==21*15+8
    letter='V';
elseif vd==21*15+9
    letter='V';
elseif vd==21*15+10
    letter='V';
elseif vd==21*15+11
    letter='V';
elseif vd==10*15+12
    letter='V';
elseif vd==21*15+13
    letter='V';
elseif vd==21*15+14
    letter='V';
elseif vd==21*15+15
    letter='V';

    %*-*-*-*-*

elseif vd==22*15+1
    letter='W';
elseif vd==22*15+2
    letter='W';
elseif vd==22*15+3
    letter='W';
elseif vd==22*15+4
    letter='W';
elseif vd==22*15+5
    letter='W';
elseif vd==22*15+6
    letter='W';
elseif vd==22*15+7
    letter='W';
elseif vd==22*15+8
    letter='W';
elseif vd==22*15+9
    letter='W';
elseif vd==22*15+10
    letter='W';
elseif vd==22*15+11
    letter='W';
elseif vd==22*15+12
    letter='W';
elseif vd==22*15+13
    letter='W';
elseif vd==22*15+14
    letter='W';
elseif vd==22*15+15
    letter='W';

    %*-*-*-*-*
elseif vd==23*15+1
    letter='X';
elseif vd==23*15+2
    letter='X';
elseif vd==23*15+3
    letter='X';
elseif vd==23*15+4
    letter='X';
elseif vd==23*15+5
    letter='X';
elseif vd==23*15+6
    letter='X';
elseif vd==23*15+7
    letter='X';
elseif vd==23*15+8
    letter='X';
elseif vd==23*15+9
    letter='X';
elseif vd==23*15+10
    letter='X';
elseif vd==23*15+11
    letter='X';
elseif vd==23*15+12
    letter='X';
elseif vd==23*15+13
    letter='X';
elseif vd==23*15+14
    letter='X';
elseif vd==23*15+15
    letter='X';

    %*-*-*-*-*

elseif vd==24*15+1
    letter='Y';
elseif vd==24*15+2
    letter='Y';
elseif vd==24*15+3
    letter='Y';
elseif vd==24*15+4
    letter='Y';
elseif vd==24*15+5
    letter='Y';
elseif vd==24*15+6
    letter='Y';
elseif vd==24*15+7
    letter='Y';
elseif vd==24*15+8
    letter='Y';
elseif vd==24*15+9
    letter='Y';
elseif vd==24*15+10
    letter='Y';
elseif vd==24*15+11
    letter='Y';
elseif vd==24*15+12
    letter='Y';
elseif vd==24*15+13
    letter='Y';
elseif vd==24*15+14
    letter='Y';
elseif vd==24*15+15
    letter='Y';

%*-*-*-*-*

elseif vd==25*15+1
    letter='Z';
elseif vd==25*15+2
    letter='Z';
elseif vd==25*15+3
    letter='Z';
elseif vd==25*15+4
    letter='Z';
elseif vd==25*15+5
    letter='Z';
elseif vd==25*15+6
    letter='Z';
elseif vd==25*15+7
    letter='Z';
elseif vd==25*15+8
    letter='Z';
elseif vd==25*15+9
    letter='Z';
elseif vd==25*15+10
    letter='Z';
elseif vd==25*15+11
    letter='Z';
elseif vd==25*15+12
    letter='Z';
elseif vd==25*15+13
    letter='Z';
elseif vd==25*15+14
    letter='Z';
elseif vd==25*15+15
    letter='Z';

    %*-*-*-*-*
elseif vd==26*15+1
    letter='A';
elseif vd==26*15+2
    letter='B';
elseif vd==26*15+3
    letter='C';
elseif vd==26*15+4
    letter='D';
elseif vd==26*15+5
    letter='E';
elseif vd==26*15+6
    letter='F';
elseif vd==26*15+7
    letter='G';
elseif vd==26*15+8
    letter='H';
elseif vd==26*15+9
    letter='I';
elseif vd==26*15+10
    letter='J';
elseif vd==26*15+11
    letter='K';
elseif vd==26*15+12
    letter='L';
elseif vd==26*15+13
    letter='M';
elseif vd==26*15+14
    letter='N';
elseif vd==26*15+15
    letter='O';
elseif vd==26*15+16
    letter='P';
elseif vd==26*15+17
    letter='Q';
elseif vd==26*15+18
    letter='R';
elseif vd==26*15+19
    letter='S';
elseif vd==26*15+20
    letter='T';
elseif vd==26*15+21
    letter='U';
elseif vd==26*15+22
    letter='V';
elseif vd==26*15+23
    letter='W';
elseif vd==26*15+24
    letter='X';
elseif vd==26*15+25
    letter='Y';
elseif vd==26*15+26
    letter='Z';
    %*-*-*-*-*


else
    letter='l';
    %*-*-*-*-*
end

