
function letter=read_letter(imagn,num_letras)

global templates
comp=[ ];


 for n=1:num_letras
    
    sem=corr2(templates{1,n},imagn);
    comp=[comp sem];
    
    %pause(1)
end

vd=find(comp==max(comp));
%*-*-*-*-*-*-*-*-*-*-*-*-*-
if vd==1
    letter='A';
elseif vd==2
    letter='A';
elseif vd==3
    letter='A';
elseif vd==4
    letter='A';
elseif vd==5
    letter='A';
elseif vd==6
    letter='A';
elseif vd==7
    letter='A';
elseif vd==8
    letter='A';
elseif vd==9
    letter='A';
elseif vd==10
    letter='A';
elseif vd==11
    letter='A';
elseif vd==12
    letter='A';
elseif vd==13
    letter='A';
elseif vd==14
    letter='A';
elseif vd==15
    letter='A';
elseif vd==16
    letter='A';
elseif vd==17
    letter='A';
elseif vd==18
    letter='A';
elseif vd==19
    letter='A';
    

    %*-*-*-*-*

elseif vd==19+1
    letter='B';
elseif vd==19+2
    letter='B';
elseif vd==19+3
    letter='B';
elseif vd==19+4
    letter='B';
elseif vd==19+5
    letter='B';
elseif vd==19+6
    letter='B';
elseif vd==19+7
    letter='B';
elseif vd==19+8
    letter='B';
elseif vd==19+9
    letter='B';
elseif vd==19+10
    letter='B';
elseif vd==19+11
    letter='B';
elseif vd==19+12
    letter='B';
elseif vd==19+13
    letter='B';
elseif vd==19+14
    letter='B';
elseif vd==19+15
    letter='B';
elseif vd==19+16
    letter='B';
elseif vd==19+17
    letter='B';
elseif vd==19+18
    letter='B';
elseif vd==19+19
    letter='B';

%*-*-*-*-*

elseif vd==2*19+1
    letter='C';
elseif vd==2*19+2
    letter='C';
elseif vd==2*19+3
    letter='C';
elseif vd==2*19+4
    letter='C';
elseif vd==2*19+5
    letter='C';
elseif vd==2*19+6
    letter='C';
elseif vd==2*19+7
    letter='C';
elseif vd==2*19+8
    letter='C';
elseif vd==2*19+9
    letter='C';
elseif vd==2*19+10
    letter='C';
elseif vd==2*19+11
    letter='C';
elseif vd==2*19+12
    letter='C';
elseif vd==2*19+13
    letter='C';
elseif vd==2*19+14
    letter='C';
elseif vd==2*19+15
    letter='C';
elseif vd==2*19+16
    letter='C';
elseif vd==2*19+17
    letter='C';
elseif vd==2*19+18
    letter='C';
elseif vd==2*19+19
    letter='C';

    %*-*-*-*-*

elseif vd==3*19+1
    letter='D';
elseif vd==3*19+2
    letter='D';
elseif vd==3*19+3
    letter='D';
elseif vd==3*19+4
    letter='D';
elseif vd==3*19+5
    letter='D';
elseif vd==3*19+6
    letter='D';
elseif vd==3*19+7
    letter='D';
elseif vd==3*19+8
    letter='D';
elseif vd==3*19+9
    letter='D';
elseif vd==3*19+10
    letter='D';
elseif vd==3*19+11
    letter='D';
elseif vd==3*19+12
    letter='D';
elseif vd==3*19+13
    letter='D';
elseif vd==3*19+14
    letter='D';
elseif vd==3*19+15
    letter='D';
elseif vd==3*19+16
    letter='D';
elseif vd==3*19+17
    letter='D';
elseif vd==3*19+18
    letter='D';
elseif vd==3*19+19
    letter='D';

    %*-*-*-*-*
elseif vd==4*19+1
    letter='E';
elseif vd==4*19+2
    letter='E';
elseif vd==4*19+3
    letter='E';
elseif vd==4*19+4
    letter='E';
elseif vd==4*19+5
    letter='E';
elseif vd==4*19+6
    letter='E';
elseif vd==4*19+7
    letter='E';
elseif vd==4*19+8
    letter='E';
elseif vd==4*19+9
    letter='E';
elseif vd==4*19+10
    letter='E';
elseif vd==4*19+11
    letter='E';
elseif vd==4*19+12
    letter='E';
elseif vd==4*19+13
    letter='E';
elseif vd==4*19+14
    letter='E';
elseif vd==4*19+15
    letter='E';
elseif vd==4*19+16
    letter='E';
elseif vd==4*19+17
    letter='E';
elseif vd==4*19+18
    letter='E';
elseif vd==4*19+19
    letter='E';

    %*-*-*-*-*

elseif vd==5*19+1
    letter='F';
elseif vd==5*19+2
    letter='F';
elseif vd==5*19+3
    letter='F';
elseif vd==5*19+4
    letter='F';
elseif vd==5*19+5
    letter='F';
elseif vd==5*19+6
    letter='F';
elseif vd==5*19+7
    letter='F';
elseif vd==5*19+8
    letter='F';
elseif vd==5*19+9
    letter='F';
elseif vd==5*19+10
    letter='F';
elseif vd==5*19+11
    letter='F';
elseif vd==5*19+12
    letter='F';
elseif vd==5*19+13
    letter='F';
elseif vd==5*19+14
    letter='F';
elseif vd==5*19+15
    letter='F';
elseif vd==5*19+16
    letter='F';
elseif vd==5*19+17
    letter='F';
elseif vd==5*19+18
    letter='F';
elseif vd==5*19+19
    letter='F';

%*-*-*-*-*

elseif vd==6*19+1
    letter='G';
elseif vd==6*19+2
    letter='G';
elseif vd==6*19+3
    letter='G';
elseif vd==6*19+4
    letter='G';
elseif vd==6*19+5
    letter='G';
elseif vd==6*19+6
    letter='G';
elseif vd==6*19+7
    letter='G';
elseif vd==6*19+8
    letter='G';
elseif vd==6*19+9
    letter='G';
elseif vd==6*19+10
    letter='G';
elseif vd==6*19+11
    letter='G';
elseif vd==6*19+12
    letter='G';
elseif vd==6*19+13
    letter='G';
elseif vd==6*19+14
    letter='G';
elseif vd==6*19+15
    letter='G';
elseif vd==6*19+16
    letter='G';
elseif vd==6*19+17
    letter='G';
elseif vd==6*19+18
    letter='G';
elseif vd==6*19+19
    letter='G';

    %*-*-*-*-*

elseif vd==7*19+1
    letter='H';
elseif vd==7*19+2
    letter='H';
elseif vd==7*19+3
    letter='H';
elseif vd==7*19+4
    letter='H';
elseif vd==7*19+5
    letter='H';
elseif vd==7*19+6
    letter='H';
elseif vd==7*19+7
    letter='H';
elseif vd==7*19+8
    letter='H';
elseif vd==7*19+9
    letter='H';
elseif vd==7*19+10
    letter='H';
elseif vd==7*19+11
    letter='H';
elseif vd==7*19+12
    letter='H';
elseif vd==7*19+13
    letter='H';
elseif vd==7*19+14
    letter='H';
elseif vd==7*19+15
    letter='H';
elseif vd==7*19+16
    letter='H';
elseif vd==7*19+17
    letter='H';
elseif vd==7*19+18
    letter='H';
elseif vd==7*19+19
    letter='H';

    %*-*-*-*-*
elseif vd==8*19+1
    letter='I';
elseif vd==8*19+2
    letter='I';
elseif vd==8*19+3
    letter='I';
elseif vd==8*19+4
    letter='I';
elseif vd==8*19+5
    letter='I';
elseif vd==8*19+6
    letter='I';
elseif vd==8*19+7
    letter='I';
elseif vd==8*19+8
    letter='I';
elseif vd==8*19+9
    letter='I';
elseif vd==8*19+10
    letter='I';
elseif vd==8*19+11
    letter='I';
elseif vd==8*19+12
    letter='I';
elseif vd==8*19+13
    letter='I';
elseif vd==8*19+14
    letter='I';
elseif vd==8*19+15
    letter='I';
elseif vd==8*19+16
    letter='I';
elseif vd==8*19+17
    letter='I';
elseif vd==8*19+18
    letter='I';
elseif vd==8*19+19
    letter='I';

    %*-*-*-*-*

elseif vd==9*19+1
    letter='J';
elseif vd==9*19+2
    letter='J';
elseif vd==9*19+3
    letter='J';
elseif vd==9*19+4
    letter='J';
elseif vd==9*19+5
    letter='J';
elseif vd==9*19+6
    letter='J';
elseif vd==9*19+7
    letter='J';
elseif vd==9*19+8
    letter='J';
elseif vd==9*19+9
    letter='J';
elseif vd==9*19+10
    letter='J';
elseif vd==9*19+11
    letter='J';
elseif vd==9*19+12
    letter='J';
elseif vd==9*19+13
    letter='J';
elseif vd==9*19+14
    letter='J';
elseif vd==9*19+15
    letter='J';
elseif vd==9*19+16
    letter='J';
elseif vd==9*19+17
    letter='J';
elseif vd==9*19+18
    letter='J';
elseif vd==9*19+19
    letter='J';

%*-*-*-*-*

elseif vd==10*19+1
    letter='K';
elseif vd==10*19+2
    letter='K';
elseif vd==10*19+3
    letter='K';
elseif vd==10*19+4
    letter='K';
elseif vd==10*19+5
    letter='K';
elseif vd==10*19+6
    letter='K';
elseif vd==10*19+7
    letter='K';
elseif vd==10*19+8
    letter='K';
elseif vd==10*19+9
    letter='K';
elseif vd==10*19+10
    letter='K';
elseif vd==10*19+11
    letter='K';
elseif vd==10*19+12
    letter='K';
elseif vd==10*19+13
    letter='K';
elseif vd==10*19+14
    letter='K';
elseif vd==10*19+15
    letter='K';
elseif vd==10*19+16
    letter='K';
elseif vd==10*19+17
    letter='K';
elseif vd==10*19+18
    letter='K';
elseif vd==10*19+19
    letter='K';

    %*-*-*-*-*

elseif vd==11*19+1
    letter='L';
elseif vd==11*19+2
    letter='L';
elseif vd==11*19+3
    letter='L';
elseif vd==11*19+4
    letter='L';
elseif vd==11*19+5
    letter='L';
elseif vd==11*19+6
    letter='L';
elseif vd==11*19+7
    letter='L';
elseif vd==11*19+8
    letter='L';
elseif vd==11*19+9
    letter='L';
elseif vd==11*19+10
    letter='L';
elseif vd==11*19+11
    letter='L';
elseif vd==11*19+12
    letter='L';
elseif vd==11*19+13
    letter='L';
elseif vd==11*19+14
    letter='L';
elseif vd==11*19+15
    letter='L';
elseif vd==11*19+16
    letter='L';
elseif vd==11*19+17
    letter='L';
elseif vd==11*19+18
    letter='L';
elseif vd==11*19+19
    letter='L';

    %*-*-*-*-*
elseif vd==12*19+1
    letter='M';
elseif vd==12*19+2
    letter='M';
elseif vd==12*19+3
    letter='M';
elseif vd==12*19+4
    letter='M';
elseif vd==12*19+5
    letter='M';
elseif vd==12*19+6
    letter='M';
elseif vd==12*19+7
    letter='M';
elseif vd==12*19+8
    letter='M';
elseif vd==12*19+9
    letter='M';
elseif vd==12*19+10
    letter='M';
elseif vd==12*19+11
    letter='M';
elseif vd==12*19+12
    letter='M';
elseif vd==12*19+13
    letter='M';
elseif vd==12*19+14
    letter='M';
elseif vd==12*19+15
    letter='M';
elseif vd==12*19+16
    letter='M';
elseif vd==12*19+17
    letter='M';
elseif vd==12*19+18
    letter='M';
elseif vd==12*19+19
    letter='M';

    %*-*-*-*-*

elseif vd==13*19+1
    letter='N';
elseif vd==13*19+2
    letter='N';
elseif vd==13*19+3
    letter='N';
elseif vd==13*19+4
    letter='N';
elseif vd==13*19+5
    letter='N';
elseif vd==13*19+6
    letter='N';
elseif vd==13*19+7
    letter='N';
elseif vd==13*19+8
    letter='N';
elseif vd==13*19+9
    letter='N';
elseif vd==13*19+10
    letter='N';
elseif vd==13*19+11
    letter='N';
elseif vd==13*19+12
    letter='N';
elseif vd==13*19+13
    letter='N';
elseif vd==13*19+14
    letter='N';
elseif vd==13*19+15
    letter='N';
elseif vd==13*19+16
    letter='N';
elseif vd==13*19+17
    letter='N';
elseif vd==13*19+18
    letter='N';
elseif vd==13*19+19
    letter='N';
%*-*-*-*-*

elseif vd==14*19+1
    letter='O';
elseif vd==14*19+2
    letter='O';
elseif vd==14*19+3
    letter='O';
elseif vd==14*19+4
    letter='O';
elseif vd==14*19+5
    letter='O';
elseif vd==14*19+6
    letter='O';
elseif vd==14*19+7
    letter='O';
elseif vd==14*19+8
    letter='O';
elseif vd==14*19+9
    letter='O';
elseif vd==14*19+10
    letter='O';
elseif vd==14*19+11
    letter='O';
elseif vd==14*19+12
    letter='O';
elseif vd==14*19+13
    letter='O';
elseif vd==14*19+14
    letter='O';
elseif vd==14*19+15
    letter='O';
elseif vd==14*19+16
    letter='O';
elseif vd==14*19+17
    letter='O';
elseif vd==14*19+18
    letter='O';
elseif vd==14*19+19
    letter='O';

    %*-*-*-*-*

elseif vd==15*19+1
    letter='P';
elseif vd==15*19+2
    letter='P';
elseif vd==15*19+3
    letter='P';
elseif vd==15*19+4
    letter='P';
elseif vd==15*19+5
    letter='P';
elseif vd==15*19+6
    letter='P';
elseif vd==15*19+7
    letter='P';
elseif vd==15*19+8
    letter='P';
elseif vd==15*19+9
    letter='P';
elseif vd==15*19+10
    letter='P';
elseif vd==15*19+11
    letter='P';
elseif vd==15*19+12
    letter='P';
elseif vd==15*19+13
    letter='P';
elseif vd==15*19+14
    letter='P';
elseif vd==15*19+15
    letter='P';
elseif vd==15*19+16
    letter='P';
elseif vd==15*19+17
    letter='P';
elseif vd==15*19+18
    letter='P';
elseif vd==15*19+19
    letter='P';

    %*-*-*-*-*
    

elseif vd==16*19+1
    letter='Q';
elseif vd==16*19+2
    letter='Q';
elseif vd==16*19+3
    letter='Q';
elseif vd==16*19+4
    letter='Q';
elseif vd==16*19+5
    letter='Q';
elseif vd==16*19+6
    letter='Q';
elseif vd==16*19+7
    letter='Q';
elseif vd==16*19+8
    letter='Q';
elseif vd==16*19+9
    letter='Q';
elseif vd==16*19+10
    letter='Q';
elseif vd==16*19+11
    letter='Q';
elseif vd==16*19+12
    letter='Q';
elseif vd==16*19+13
    letter='Q';
elseif vd==16*19+14
    letter='Q';
elseif vd==16*19+15
    letter='Q';
elseif vd==16*19+16
    letter='Q';
elseif vd==16*19+17
    letter='Q';
elseif vd==16*19+18
    letter='Q';
elseif vd==16*19+19
    letter='Q';

%*-*-*-*-*

elseif vd==17*19+1
    letter='R';
elseif vd==17*19+2
    letter='R';
elseif vd==17*19+3
    letter='R';
elseif vd==17*19+4
    letter='R';
elseif vd==17*19+5
    letter='R';
elseif vd==17*19+6
    letter='R';
elseif vd==17*19+7
    letter='R';
elseif vd==17*19+8
    letter='R';
elseif vd==17*19+9
    letter='R';
elseif vd==17*19+10
    letter='R';
elseif vd==17*19+11
    letter='R';
elseif vd==17*19+12
    letter='R';
elseif vd==17*19+13
    letter='R';
elseif vd==17*19+14
    letter='R';
elseif vd==17*19+15
    letter='R';
elseif vd==17*19+16
    letter='R';
elseif vd==17*19+17
    letter='R';
elseif vd==17*19+18
    letter='R';
elseif vd==17*19+19
    letter='R';

    %*-*-*-*-*

elseif vd==18*19+1
    letter='S';
elseif vd==18*19+2
    letter='S';
elseif vd==18*19+3
    letter='S';
elseif vd==18*19+4
    letter='S';
elseif vd==18*19+5
    letter='S';
elseif vd==18*19+6
    letter='S';
elseif vd==18*19+7
    letter='S';
elseif vd==18*19+8
    letter='S';
elseif vd==18*19+9
    letter='S';
elseif vd==18*19+10
    letter='S';
elseif vd==18*19+11
    letter='S';
elseif vd==18*19+12
    letter='S';
elseif vd==18*19+13
    letter='S';
elseif vd==18*19+14
    letter='S';
elseif vd==18*19+15
    letter='S';
elseif vd==18*19+16
    letter='S';
elseif vd==18*19+17
    letter='S';
elseif vd==18*19+18
    letter='S';
elseif vd==18*19+19
    letter='S';

    %*-*-*-*-*
elseif vd==19*19+1
    letter='T';
elseif vd==19*19+2
    letter='T';
elseif vd==19*19+3
    letter='T';
elseif vd==19*19+4
    letter='T';
elseif vd==19*19+5
    letter='T';
elseif vd==19*19+6
    letter='T';
elseif vd==19*19+7
    letter='T';
elseif vd==19*19+8
    letter='T';
elseif vd==19*19+9
    letter='T';
elseif vd==19*19+10
    letter='T';
elseif vd==19*19+11
    letter='T';
elseif vd==19*19+12
    letter='T';
elseif vd==19*19+13
    letter='T';
elseif vd==19*19+14
    letter='T';
elseif vd==19*19+15
    letter='T';
elseif vd==19*19+16
    letter='T';
elseif vd==19*19+17
    letter='T';
elseif vd==19*19+18
    letter='T';
elseif vd==19*19+19
    letter='T';

    %*-*-*-*-*

elseif vd==20*19+1
    letter='U';
elseif vd==20*19+2
    letter='U';
elseif vd==20*19+3
    letter='U';
elseif vd==20*19+4
    letter='U';
elseif vd==20*19+5
    letter='U';
elseif vd==20*19+6
    letter='U';
elseif vd==20*19+7
    letter='U';
elseif vd==20*19+8
    letter='U';
elseif vd==20*19+9
    letter='U';
elseif vd==20*19+10
    letter='U';
elseif vd==20*19+11
    letter='U';
elseif vd==20*19+12
    letter='U';
elseif vd==20*19+13
    letter='U';
elseif vd==20*19+14
    letter='U';
elseif vd==20*19+15
    letter='U';
elseif vd==20*19+16
    letter='U';
elseif vd==20*19+17
    letter='U';
elseif vd==20*19+18
    letter='U';
elseif vd==20*19+19
    letter='U';

%*-*-*-*-*

elseif vd==21*19+1
    letter='V';
elseif vd==21*19+2
    letter='V';
elseif vd==21*19+3
    letter='V';
elseif vd==21*19+4
    letter='V';
elseif vd==21*19+5
    letter='V';
elseif vd==21*19+6
    letter='V';
elseif vd==21*19+7
    letter='V';
elseif vd==21*19+8
    letter='V';
elseif vd==21*19+9
    letter='V';
elseif vd==21*19+10
    letter='V';
elseif vd==21*19+11
    letter='V';
elseif vd==21*19+12
    letter='V';
elseif vd==21*19+13
    letter='V';
elseif vd==21*19+14
    letter='V';
elseif vd==21*19+15
    letter='V';
elseif vd==21*19+16
    letter='V';
elseif vd==21*19+17
    letter='V';
elseif vd==21*19+18
    letter='V';
elseif vd==21*19+19
    letter='V';

    %*-*-*-*-*

elseif vd==22*19+1
    letter='W';
elseif vd==22*19+2
    letter='W';
elseif vd==22*19+3
    letter='W';
elseif vd==22*19+4
    letter='W';
elseif vd==22*19+5
    letter='W';
elseif vd==22*19+6
    letter='W';
elseif vd==22*19+7
    letter='W';
elseif vd==22*19+8
    letter='W';
elseif vd==22*19+9
    letter='W';
elseif vd==22*19+10
    letter='W';
elseif vd==22*19+11
    letter='W';
elseif vd==22*19+12
    letter='W';
elseif vd==22*19+13
    letter='W';
elseif vd==22*19+14
    letter='W';
elseif vd==22*19+15
    letter='W';
elseif vd==22*19+16
    letter='W';
elseif vd==22*19+17
    letter='W';
elseif vd==22*19+18
    letter='W';
elseif vd==22*19+19
    letter='W';

    %*-*-*-*-*
elseif vd==23*19+1
    letter='X';
elseif vd==23*19+2
    letter='X';
elseif vd==23*19+3
    letter='X';
elseif vd==23*19+4
    letter='X';
elseif vd==23*19+5
    letter='X';
elseif vd==23*19+6
    letter='X';
elseif vd==23*19+7
    letter='X';
elseif vd==23*19+8
    letter='X';
elseif vd==23*19+9
    letter='X';
elseif vd==23*19+10
    letter='X';
elseif vd==23*19+11
    letter='X';
elseif vd==23*19+12
    letter='X';
elseif vd==23*19+13
    letter='X';
elseif vd==23*19+14
    letter='X';
elseif vd==23*19+15
    letter='X';
elseif vd==23*19+16
    letter='X';
elseif vd==23*19+17
    letter='X';
elseif vd==23*19+18
    letter='X';
elseif vd==23*19+19
    letter='X';
    %*-*-*-*-*

elseif vd==24*19+1
    letter='Y';
elseif vd==24*19+2
    letter='Y';
elseif vd==24*19+3
    letter='Y';
elseif vd==24*19+4
    letter='Y';
elseif vd==24*19+5
    letter='Y';
elseif vd==24*19+6
    letter='Y';
elseif vd==24*19+7
    letter='Y';
elseif vd==24*19+8
    letter='Y';
elseif vd==24*19+9
    letter='Y';
elseif vd==24*19+10
    letter='Y';
elseif vd==24*19+11
    letter='Y';
elseif vd==24*19+12
    letter='Y';
elseif vd==24*19+13
    letter='Y';
elseif vd==24*19+14
    letter='Y';
elseif vd==24*19+15
    letter='Y';
elseif vd==24*19+16
    letter='Y';
elseif vd==24*19+17
    letter='Y';
elseif vd==24*19+18
    letter='Y';
elseif vd==24*19+19
    letter='Y';

%*-*-*-*-*

elseif vd==25*19+1
    letter='Z';
elseif vd==25*19+2
    letter='Z';
elseif vd==25*19+3
    letter='Z';
elseif vd==25*19+4
    letter='Z';
elseif vd==25*19+5
    letter='Z';
elseif vd==25*19+6
    letter='Z';
elseif vd==25*19+7
    letter='Z';
elseif vd==25*19+8
    letter='Z';
elseif vd==25*19+9
    letter='Z';
elseif vd==25*19+10
    letter='Z';
elseif vd==25*19+11
    letter='Z';
elseif vd==25*19+12
    letter='Z';
elseif vd==25*19+13
    letter='Z';
elseif vd==25*19+14
    letter='Z';
elseif vd==25*19+15
    letter='Z';
elseif vd==25*19+16
    letter='Z';
elseif vd==25*19+17
    letter='Z';
elseif vd==25*19+18
    letter='Z';
elseif vd==25*19+19
    letter='Z';

    %*-*-*-*-*
elseif vd==26*19+1
    letter='A';
elseif vd==26*19+2
    letter='B';
elseif vd==26*19+3
    letter='C';
elseif vd==26*19+4
    letter='D';
elseif vd==26*19+5
    letter='E';
elseif vd==26*19+6
    letter='F';
elseif vd==26*19+7
    letter='G';
elseif vd==26*19+8
    letter='H';
elseif vd==26*19+9
    letter='I';
elseif vd==26*19+10
    letter='J';
elseif vd==26*19+11
    letter='K';
elseif vd==26*19+12
    letter='L';
elseif vd==26*19+13
    letter='M';
elseif vd==26*19+14
    letter='N';
elseif vd==26*19+15
    letter='O';
elseif vd==26*19+16
    letter='P';
elseif vd==26*19+17
    letter='Q';
elseif vd==26*19+18
    letter='R';
elseif vd==26*19+19
    letter='S';
elseif vd==26*19+20
    letter='T';
elseif vd==26*19+21
    letter='U';
elseif vd==26*19+22
    letter='V';
elseif vd==26*19+23
    letter='W';
elseif vd==26*19+24
    letter='X';
elseif vd==26*19+25
    letter='Y';
elseif vd==26*19+26
    letter='Z';
    %*-*-*-*-*


else
    letter='*';
    %*-*-*-*-*
end

