%CREATE TEMPLATES
%Letter
clc;
close all;
A=imread('New folder\A.bmp');B=imread('New folder\B.bmp');
C=imread('New folder\C.bmp');D=imread('New folder\D.bmp');
E=imread('New folder\E.bmp');F=imread('New folder\F.bmp');
G=imread('New folder\G.bmp');H=imread('New folder\H.bmp');
I=imread('New folder\I.bmp');J=imread('New folder\J.bmp');
K=imread('New folder\K.bmp');L=imread('New folder\L.bmp');
M=imread('New folder\M.bmp');N=imread('New folder\N.bmp');
O=imread('New folder\O.bmp');P=imread('New folder\P.bmp');
Q=imread('New folder\Q.bmp');R=imread('New folder\R.bmp');
S=imread('New folder\S.bmp');T=imread('New folder\T.bmp');
U=imread('New folder\U.bmp');V=imread('New folder\V.bmp');
W=imread('New folder\W.bmp');X=imread('New folder\X.bmp');
Y=imread('New folder\Y.bmp');Z=imread('New folder\Z.bmp');


A1=imread('New folder\A1.jpg');B1=imread('New folder\B1.jpg');C1=imread('New folder\C1.jpg');D1=imread('New folder\D1.jpg');
E1=imread('New folder\E1.jpg');F1=imread('New folder\F1.jpg');G1=imread('New folder\G1.jpg');H1=imread('New folder\H1.jpg');
I1=imread('New folder\I1.jpg');J1=imread('New folder\J1.jpg');K1=imread('New folder\K1.jpg');L1=imread('New folder\L1.jpg');
M1=imread('New folder\M1.jpg');N1=imread('New folder\N1.jpg');O1=imread('New folder\O1.jpg');P1=imread('New folder\P1.jpg');
Q1=imread('New folder\Q1.jpg');R1=imread('New folder\R1.jpg');S1=imread('New folder\S1.jpg');T1=imread('New folder\T1.jpg');
U1=imread('New folder\U1.jpg');V1=imread('New folder\V1.jpg');W1=imread('New folder\W1.jpg');X1=imread('New folder\X1.jpg');
Y1=imread('New folder\Y1.jpg');Z1=imread('New folder\Z1.jpg');

A2=imread('New folder\A2.jpg');B2=imread('New folder\B2.jpg');C2=imread('New folder\C2.jpg');D2=imread('New folder\D2.jpg');
E2=imread('New folder\E2.jpg');F2=imread('New folder\F2.jpg');G2=imread('New folder\G2.jpg');H2=imread('New folder\H2.jpg');
I2=imread('New folder\I2.jpg');J2=imread('New folder\J2.jpg');K2=imread('New folder\K2.jpg');L2=imread('New folder\L2.jpg');
M2=imread('New folder\M2.jpg');N2=imread('New folder\N2.jpg');O2=imread('New folder\O2.jpg');P2=imread('New folder\P2.jpg');
Q2=imread('New folder\Q2.jpg');R2=imread('New folder\R2.jpg');S2=imread('New folder\S2.jpg');T2=imread('New folder\T2.jpg');
U2=imread('New folder\U2.jpg');V2=imread('New folder\V2.jpg');W2=imread('New folder\W2.jpg');X2=imread('New folder\X2.jpg');
Y2=imread('New folder\Y2.jpg');Z2=imread('New folder\Z2.jpg');

A3=imread('New folder\A3.jpg');B3=imread('New folder\B3.jpg');C3=imread('New folder\C3.jpg');D3=imread('New folder\D3.jpg');
E3=imread('New folder\E3.jpg');F3=imread('New folder\F3.jpg');G3=imread('New folder\G3.jpg');H3=imread('New folder\H3.jpg');
I3=imread('New folder\I3.jpg');J3=imread('New folder\J3.jpg');K3=imread('New folder\K3.jpg');L3=imread('New folder\L3.jpg');
M3=imread('New folder\M3.jpg');N3=imread('New folder\N3.jpg');O3=imread('New folder\O3.jpg');P3=imread('New folder\P3.jpg');
Q3=imread('New folder\Q3.jpg');R3=imread('New folder\R3.jpg');S3=imread('New folder\S3.jpg');T3=imread('New folder\T3.jpg');
U3=imread('New folder\U3.jpg');V3=imread('New folder\V3.jpg');W3=imread('New folder\W3.jpg');X3=imread('New folder\X3.jpg');
Y3=imread('New folder\Y3.jpg');Z3=imread('New folder\Z3.jpg');

A4=imread('New folder\A4.jpg');B4=imread('New folder\B4.jpg');C4=imread('New folder\C4.jpg');D4=imread('New folder\D4.jpg');
E4=imread('New folder\E4.jpg');F4=imread('New folder\F4.jpg');G4=imread('New folder\G4.jpg');H4=imread('New folder\H4.jpg');
I4=imread('New folder\I4.jpg');J4=imread('New folder\J4.jpg');K4=imread('New folder\K4.jpg');L4=imread('New folder\L4.jpg');
M4=imread('New folder\M4.jpg');N4=imread('New folder\N4.jpg');O4=imread('New folder\O4.jpg');P4=imread('New folder\P4.jpg');
Q4=imread('New folder\Q4.jpg');R4=imread('New folder\R4.jpg');S4=imread('New folder\S4.jpg');T4=imread('New folder\T4.jpg');
U4=imread('New folder\U4.jpg');V4=imread('New folder\V4.jpg');W4=imread('New folder\W4.jpg');X4=imread('New folder\X4.jpg');
Y4=imread('New folder\Y4.jpg');Z4=imread('New folder\Z4.jpg');

A5=imread('New folder\A5.jpg');B5=imread('New folder\B5.jpg');C5=imread('New folder\C5.jpg');D5=imread('New folder\D5.jpg');
E5=imread('New folder\E5.jpg');F5=imread('New folder\F5.jpg');G5=imread('New folder\G5.jpg');H5=imread('New folder\H5.jpg');
I5=imread('New folder\I5.jpg');J5=imread('New folder\J5.jpg');K5=imread('New folder\K5.jpg');L5=imread('New folder\L5.jpg');
M5=imread('New folder\M5.jpg');N5=imread('New folder\N5.jpg');O5=imread('New folder\O5.jpg');P5=imread('New folder\P5.jpg');
Q5=imread('New folder\Q5.jpg');R5=imread('New folder\R5.jpg');S5=imread('New folder\S5.jpg');T5=imread('New folder\T5.jpg');
U5=imread('New folder\U5.jpg');V5=imread('New folder\V5.jpg');W5=imread('New folder\W5.jpg');X5=imread('New folder\X5.jpg');
Y5=imread('New folder\Y5.jpg');Z5=imread('New folder\Z5.jpg');

A6=imread('New folder\A6.jpg');B6=imread('New folder\B6.jpg');C6=imread('New folder\C6.jpg');D6=imread('New folder\D6.jpg');
E6=imread('New folder\E6.jpg');F6=imread('New folder\F6.jpg');G6=imread('New folder\G6.jpg');H6=imread('New folder\H6.jpg');
I6=imread('New folder\I6.jpg');J6=imread('New folder\J6.jpg');K6=imread('New folder\K6.jpg');L6=imread('New folder\L6.jpg');
M6=imread('New folder\M6.jpg');N6=imread('New folder\N6.jpg');O6=imread('New folder\O6.jpg');P6=imread('New folder\P6.jpg');
Q6=imread('New folder\Q6.jpg');R6=imread('New folder\R6.jpg');S6=imread('New folder\S6.jpg');T6=imread('New folder\T6.jpg');
U6=imread('New folder\U6.jpg');V6=imread('New folder\V6.jpg');W6=imread('New folder\W6.jpg');X6=imread('New folder\X6.jpg');
Y6=imread('New folder\Y6.jpg');Z6=imread('New folder\Z6.jpg');

A7=imread('New folder\A7.jpg');B7=imread('New folder\B7.jpg');C7=imread('New folder\C7.jpg');D7=imread('New folder\D7.jpg');
E7=imread('New folder\E7.jpg');F7=imread('New folder\F7.jpg');G7=imread('New folder\G7.jpg');H7=imread('New folder\H7.jpg');
I7=imread('New folder\I7.jpg');J7=imread('New folder\J7.jpg');K7=imread('New folder\K7.jpg');L7=imread('New folder\L7.jpg');
M7=imread('New folder\M7.jpg');N7=imread('New folder\N7.jpg');O7=imread('New folder\O7.jpg');P7=imread('New folder\P7.jpg');
Q7=imread('New folder\Q7.jpg');R7=imread('New folder\R7.jpg');S7=imread('New folder\S7.jpg');T7=imread('New folder\T7.jpg');
U7=imread('New folder\U7.jpg');V7=imread('New folder\V7.jpg');W7=imread('New folder\W7.jpg');X7=imread('New folder\X7.jpg');
Y7=imread('New folder\Y7.jpg');Z7=imread('New folder\Z7.jpg');

A8=imread('New folder\A8.jpg');B8=imread('New folder\B8.jpg');C8=imread('New folder\C8.jpg');D8=imread('New folder\D8.jpg');
E8=imread('New folder\E8.jpg');F8=imread('New folder\F8.jpg');G8=imread('New folder\G8.jpg');H8=imread('New folder\H8.jpg');
I8=imread('New folder\I8.jpg');J8=imread('New folder\J8.jpg');K8=imread('New folder\K8.jpg');L8=imread('New folder\L8.jpg');
M8=imread('New folder\M8.jpg');N8=imread('New folder\N8.jpg');O8=imread('New folder\O8.jpg');P8=imread('New folder\P8.jpg');
Q8=imread('New folder\Q8.jpg');R8=imread('New folder\R8.jpg');S8=imread('New folder\S8.jpg');T8=imread('New folder\T8.jpg');
U8=imread('New folder\U8.jpg');V8=imread('New folder\V8.jpg');W8=imread('New folder\W8.jpg');X8=imread('New folder\X8.jpg');
Y8=imread('New folder\Y8.jpg');Z8=imread('New folder\Z8.jpg');

A9=imread('New folder\A9.jpg');B9=imread('New folder\B9.jpg');C9=imread('New folder\C9.jpg');D9=imread('New folder\D9.jpg');
E9=imread('New folder\E9.jpg');F9=imread('New folder\F9.jpg');G9=imread('New folder\G9.jpg');H9=imread('New folder\H9.jpg');
I9=imread('New folder\I9.jpg');J9=imread('New folder\J9.jpg');K9=imread('New folder\K9.jpg');L9=imread('New folder\L9.jpg');
M9=imread('New folder\M9.jpg');N9=imread('New folder\N9.jpg');O9=imread('New folder\O9.jpg');P9=imread('New folder\P9.jpg');
Q9=imread('New folder\Q9.jpg');R9=imread('New folder\R9.jpg');S9=imread('New folder\S9.jpg');T9=imread('New folder\T9.jpg');
U9=imread('New folder\U9.jpg');V9=imread('New folder\V9.jpg');W9=imread('New folder\W9.jpg');X9=imread('New folder\X9.jpg');
Y9=imread('New folder\Y9.jpg');Z9=imread('New folder\Z9.jpg');

A10=imread('New folder\A10.jpg');B10=imread('New folder\B10.jpg');C10=imread('New folder\C10.jpg');D10=imread('New folder\D10.jpg');
E10=imread('New folder\E10.jpg');F10=imread('New folder\F10.jpg');G10=imread('New folder\G10.jpg');H10=imread('New folder\H10.jpg');
I10=imread('New folder\I10.jpg');J10=imread('New folder\J10.jpg');K10=imread('New folder\K10.jpg');L10=imread('New folder\L10.jpg');
M10=imread('New folder\M10.jpg');N10=imread('New folder\N10.jpg');O10=imread('New folder\O10.jpg');P10=imread('New folder\P10.jpg');
Q10=imread('New folder\Q10.jpg');R10=imread('New folder\R10.jpg');S10=imread('New folder\S10.jpg');T10=imread('New folder\T10.jpg');
U10=imread('New folder\U10.jpg');V10=imread('New folder\V10.jpg');W10=imread('New folder\W10.jpg');X10=imread('New folder\X10.jpg');
Y10=imread('New folder\Y10.jpg');Z10=imread('New folder\Z10.jpg');

A11=imread('New folder\A11.jpg');B11=imread('New folder\B11.jpg');C11=imread('New folder\C11.jpg');D11=imread('New folder\D11.jpg');
E11=imread('New folder\E11.jpg');F11=imread('New folder\F11.jpg');G11=imread('New folder\G11.jpg');H11=imread('New folder\H11.jpg');
I11=imread('New folder\I11.jpg');J11=imread('New folder\J11.jpg');K11=imread('New folder\K11.jpg');L11=imread('New folder\L11.jpg');
M11=imread('New folder\M11.jpg');N11=imread('New folder\N11.jpg');O11=imread('New folder\O11.jpg');P11=imread('New folder\P11.jpg');
Q11=imread('New folder\Q11.jpg');R11=imread('New folder\R11.jpg');S11=imread('New folder\S11.jpg');T11=imread('New folder\T11.jpg');
U11=imread('New folder\U11.jpg');V11=imread('New folder\V11.jpg');W11=imread('New folder\W11.jpg');X11=imread('New folder\X11.jpg');
Y11=imread('New folder\Y11.jpg');Z11=imread('New folder\Z11.jpg');

A12=imread('New folder\A12.jpg');B12=imread('New folder\B12.jpg');C12=imread('New folder\C12.jpg');D12=imread('New folder\D12.jpg');
E12=imread('New folder\E12.jpg');F12=imread('New folder\F12.jpg');G12=imread('New folder\G12.jpg');H12=imread('New folder\H12.jpg');
I12=imread('New folder\I12.jpg');J12=imread('New folder\J12.jpg');K12=imread('New folder\K12.jpg');L12=imread('New folder\L12.jpg');
M12=imread('New folder\M12.jpg');N12=imread('New folder\N12.jpg');O12=imread('New folder\O12.jpg');P12=imread('New folder\P12.jpg');
Q12=imread('New folder\Q12.jpg');R12=imread('New folder\R12.jpg');S12=imread('New folder\S12.jpg');T12=imread('New folder\T12.jpg');
U12=imread('New folder\U12.jpg');V12=imread('New folder\V12.jpg');W12=imread('New folder\W12.jpg');X12=imread('New folder\X12.jpg');
Y12=imread('New folder\Y12.jpg');Z12=imread('New folder\Z12.jpg');

A13=imread('New folder\A13.jpg');B13=imread('New folder\B13.jpg');C13=imread('New folder\C13.jpg');D13=imread('New folder\D13.jpg');
E13=imread('New folder\E13.jpg');F13=imread('New folder\F13.jpg');G13=imread('New folder\G13.jpg');H13=imread('New folder\H13.jpg');
I13=imread('New folder\I13.jpg');J13=imread('New folder\J13.jpg');K13=imread('New folder\K13.jpg');L13=imread('New folder\L13.jpg');
M13=imread('New folder\M13.jpg');N13=imread('New folder\N13.jpg');O13=imread('New folder\O13.jpg');P13=imread('New folder\P13.jpg');
Q13=imread('New folder\Q13.jpg');R13=imread('New folder\R13.jpg');S13=imread('New folder\S13.jpg');T13=imread('New folder\T13.jpg');
U13=imread('New folder\U13.jpg');V13=imread('New folder\V13.jpg');W13=imread('New folder\W13.jpg');X13=imread('New folder\X13.jpg');
Y13=imread('New folder\Y13.jpg');Z13=imread('New folder\Z13.jpg');

A14=imread('New folder\A14.jpg');B14=imread('New folder\B14.jpg');C14=imread('New folder\C14.jpg');D14=imread('New folder\D14.jpg');
E14=imread('New folder\E14.jpg');F14=imread('New folder\F14.jpg');G14=imread('New folder\G14.jpg');H14=imread('New folder\H14.jpg');
I14=imread('New folder\I14.jpg');J14=imread('New folder\J14.jpg');K14=imread('New folder\K14.jpg');L14=imread('New folder\L14.jpg');
M14=imread('New folder\M14.jpg');N14=imread('New folder\N14.jpg');O14=imread('New folder\O14.jpg');P14=imread('New folder\P14.jpg');
Q14=imread('New folder\Q14.jpg');R14=imread('New folder\R14.jpg');S14=imread('New folder\S14.jpg');T14=imread('New folder\T14.jpg');
U14=imread('New folder\U14.jpg');V14=imread('New folder\V14.jpg');W14=imread('New folder\W14.jpg');X14=imread('New folder\X14.jpg');
Y14=imread('New folder\Y14.jpg');Z14=imread('New folder\Z14.jpg');

A15=imread('New folder\A15.jpg');B15=imread('New folder\B15.jpg');C15=imread('New folder\C15.jpg');D15=imread('New folder\D15.jpg');
E15=imread('New folder\E15.jpg');F15=imread('New folder\F15.jpg');G15=imread('New folder\G15.jpg');H15=imread('New folder\H15.jpg');
I15=imread('New folder\I15.jpg');J15=imread('New folder\J15.jpg');K15=imread('New folder\K15.jpg');L15=imread('New folder\L15.jpg');
M15=imread('New folder\M15.jpg');N15=imread('New folder\N15.jpg');O15=imread('New folder\O15.jpg');P15=imread('New folder\P15.jpg');
Q15=imread('New folder\Q15.jpg');R15=imread('New folder\R15.jpg');S15=imread('New folder\S15.jpg');T15=imread('New folder\T15.jpg');
U15=imread('New folder\U15.jpg');V15=imread('New folder\V15.jpg');W15=imread('New folder\W15.jpg');X15=imread('New folder\X15.jpg');
Y15=imread('New folder\Y15.jpg');Z15=imread('New folder\Z15.jpg');

A16=imread('New folder\A16.jpg');B16=imread('New folder\B16.jpg');C16=imread('New folder\C16.jpg');D16=imread('New folder\D16.jpg');
E16=imread('New folder\E16.jpg');F16=imread('New folder\F16.jpg');G16=imread('New folder\G16.jpg');H16=imread('New folder\H16.jpg');
I16=imread('New folder\I16.jpg');J16=imread('New folder\J16.jpg');K16=imread('New folder\K16.jpg');L16=imread('New folder\L16.jpg');
M16=imread('New folder\M16.jpg');N16=imread('New folder\N16.jpg');O16=imread('New folder\O16.jpg');P16=imread('New folder\P16.jpg');
Q16=imread('New folder\Q16.jpg');R16=imread('New folder\R16.jpg');S16=imread('New folder\S16.jpg');T16=imread('New folder\T16.jpg');
U16=imread('New folder\U16.jpg');V16=imread('New folder\V16.jpg');W16=imread('New folder\W16.jpg');X16=imread('New folder\X16.jpg');
Y16=imread('New folder\Y16.jpg');Z16=imread('New folder\Z16.jpg');

A17=imread('New folder\A17.jpg');B17=imread('New folder\B17.jpg');C17=imread('New folder\C17.jpg');D17=imread('New folder\D17.jpg');
E17=imread('New folder\E17.jpg');F17=imread('New folder\F17.jpg');G17=imread('New folder\G17.jpg');H17=imread('New folder\H17.jpg');
I17=imread('New folder\I17.jpg');J17=imread('New folder\J17.jpg');K17=imread('New folder\K17.jpg');L17=imread('New folder\L17.jpg');
M17=imread('New folder\M17.jpg');N17=imread('New folder\N17.jpg');O17=imread('New folder\O17.jpg');P17=imread('New folder\P17.jpg');
Q17=imread('New folder\Q17.jpg');R17=imread('New folder\R17.jpg');S17=imread('New folder\S17.jpg');T17=imread('New folder\T17.jpg');
U17=imread('New folder\U17.jpg');V17=imread('New folder\V17.jpg');W17=imread('New folder\W17.jpg');X17=imread('New folder\X17.jpg');
Y17=imread('New folder\Y17.jpg');Z17=imread('New folder\Z17.jpg');

A18=imread('New folder\A18.jpg');B18=imread('New folder\B18.jpg');C18=imread('New folder\C18.jpg');D18=imread('New folder\D18.jpg');
E18=imread('New folder\E18.jpg');F18=imread('New folder\F18.jpg');G18=imread('New folder\G18.jpg');H18=imread('New folder\H18.jpg');
I18=imread('New folder\I18.jpg');J18=imread('New folder\J18.jpg');K18=imread('New folder\K18.jpg');L18=imread('New folder\L18.jpg');
M18=imread('New folder\M18.jpg');N18=imread('New folder\N18.jpg');O18=imread('New folder\O18.jpg');P18=imread('New folder\P18.jpg');
Q18=imread('New folder\Q18.jpg');R18=imread('New folder\R18.jpg');S18=imread('New folder\S18.jpg');T18=imread('New folder\T18.jpg');
U18=imread('New folder\U18.jpg');V18=imread('New folder\V18.jpg');W18=imread('New folder\W18.jpg');X18=imread('New folder\X18.jpg');
Y18=imread('New folder\Y18.jpg');Z18=imread('New folder\Z18.jpg');

A19=imread('New folder\A19.jpg');B19=imread('New folder\B19.jpg');C19=imread('New folder\C19.jpg');D19=imread('New folder\D19.jpg');
E19=imread('New folder\E19.jpg');F19=imread('New folder\F19.jpg');G19=imread('New folder\G19.jpg');H19=imread('New folder\H19.jpg');
I19=imread('New folder\I19.jpg');J19=imread('New folder\J19.jpg');K19=imread('New folder\K19.jpg');L19=imread('New folder\L19.jpg');
M19=imread('New folder\M19.jpg');N19=imread('New folder\N19.jpg');O19=imread('New folder\O19.jpg');P19=imread('New folder\P19.jpg');
Q19=imread('New folder\Q19.jpg');R19=imread('New folder\R19.jpg');S19=imread('New folder\S19.jpg');T19=imread('New folder\T19.jpg');
U19=imread('New folder\U19.jpg');V19=imread('New folder\V19.jpg');W19=imread('New folder\W19.jpg');X19=imread('New folder\X19.jpg');
Y19=imread('New folder\Y19.jpg');Z19=imread('New folder\Z19.jpg');



letter=[A1 A2 A3 A4 A4 A6 A7 A8 A9 A10 A11 A12 A13 A14 A15 A16 A17 A18 A19 ...
        B1 B2 B3 B4 B5 B6 B7 B8 B9 B10 B11 B12 B13 B14 B15 B16 B17 B18 B19 ...
        C1 C2 C3 C4 C5 C6 C7 C8 C9 C10 C11 C12 C13 C14 C15 C16 C17 C18 C19 ...
        D1 D2 D3 D4 D5 D6 D7 D8 D9 D10 D11 D12 D13 D14 D15 D16 D17 D18 D19 ...
        E1 E2 E3 E4 E5 E6 E7 E8 E9 E10 E11 E12 E13 E14 E15 E16 E17 E18 E19 ...
        F1 F2 F3 F4 F5 F6 F7 F8 F9 F10 F11 F12 F13 F14 F15 F16 F17 F18 F19 ...
        G1 G2 G3 G4 G5 G6 G7 G8 G9 G10 G11 G12 G13 G14 G15 G16 G17 G18 G19 ...
        H1 H2 H3 H4 H5 H6 H7 H8 H9 H10 H11 H12 H13 H14 H15 H16 H17 H18 H19 ...
        I1 I2 I3 I4 I5 I6 I7 I8 I9 I10 I11 I12 I13 I14 I15 I16 I17 I18 I19 ...
        J1 J2 J3 J4 J5 J6 J7 J8 J9 J10 J11 J12 J13 J14 J15 J16 J17 J18 J19 ...
        K1 K2 K3 K4 K5 K6 K7 K8 K9 K10 K11 K12 K13 K14 K15 K16 K17 K18 K19 ...
        L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 L13 L14 L15 L16 L17 L18 L19 ...
        M1 M2 M3 M4 M5 M6 M7 M8 M9 M10 M11 M12 M13 M14 M15 M16 M17 M18 M19 ...
        N1 N2 N3 N4 N5 N6 N7 N8 N9 N10 N11 N12 N13 N14 N15 N16 N17 N18 N19 ...
        O1 O2 O3 O4 O5 O6 O7 O8 O9 O10 O11 O12 O13 O14 O15 O16 O17 O18 O19 ...
        P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 P11 P12 P13 P14 P15 P16 P17 P18 P19 ...
        Q1 Q2 Q3 Q4 Q5 Q6 Q7 Q8 Q9 Q10 Q11 Q12 Q13 Q14 Q15 Q16 Q17 Q18 Q19 ...
        R1 R2 R3 R4 R5 R6 R7 R8 R9 R10 R11 R12 R13 R14 R15 R16 R17 R18 R19 ...
        S1 S2 S3 S4 S5 S6 S7 S8 S9 S10 S11 S12 S13 S14 S15 S16 S17 S18 S19 ...
        T1 T2 T3 T4 T5 T6 T7 T8 T9 T10 T11 T12 T13 T14 T15 T16 T17 T18 T19 ...
        U1 U2 U3 U4 U5 U6 U7 U8 U9 U10 U11 U12 U13 U14 U15 U16 U17 U18 U19 ...
        V1 V2 V3 V4 V5 V6 V7 V8 V9 V10 V11 V12 V13 V14 V15 V16 V17 V18 V19 ...
        W1 W2 W3 W4 W5 W6 W7 W8 W9 W10 W11 W12 W13 W14 W15 W16 W17 W18 W19 ...
        X1 X2 X3 X4 X5 X6 X7 X8 X9 X10 X11 X12 X13 X14 X15 X16 X17 X18 X19 ...
        Y1 Y2 Y3 Y4 Y5 Y6 Y7 Y8 Y9 Y10 Y11 Y12 Y13 Y14 Y15 Y16 Y17 Y18 Y19 ...
        Z1 Z2 Z3 Z4 Z5 Z6 Z7 Z8 Z9 Z10 Z11 Z12 Z13 Z14 Z15 Z16 Z17 Z18 Z19 ...
        A B C D E F G H I J K L M N O P Q R S T U V W X Y Z];

character=letter;
templates=mat2cell(character,42,[24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24 ...
                                 24 24 24 24 24 24 24 24 24 24 24 24 24]);
save ('templates','templates')
 clear all