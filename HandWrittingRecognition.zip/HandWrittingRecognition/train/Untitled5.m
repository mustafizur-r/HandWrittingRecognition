
chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

for i = 1:size(chars,2)
    dat = imre);
    dat = imresize(dat,[42 24]);
    imwrite(dat,'A.jpg');
% imshow(dat);


